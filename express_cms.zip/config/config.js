var app={
    dbUrl:"mongodb://127.0.0.1:27017/express_cms",
    adminPath:"admin_express"   //此处修改完毕以后还需要修改static/admin/js/base.js
}

module.exports=app;
